<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Publicidad;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;


class PubliController extends Controller
{
    //
        

        public function MirarPubli(Request $request){


            $base = 'SELECT Nombre_publi FROM Publicidad WHERE id_publicidad=1';
            $publica = DB::select($base);
            return view('vision', ['publica'=>$publica]); 
           // return Publicidad::all();
        }
        
        public function publi(Request $request){
        return url(DB::Publicidad('Nombre_publi').$this->Nombre_publi);
    }


        
    

    }